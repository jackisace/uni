import random





strength = random.randint(3,18)
intelligence = random.randint(3,18)
wisdom = random.randint(3,18)
dexterity = random.randint(3,18)
constitution = random.randint(3,18)
strengthReq = 0
intelligenceReq = 0
wisdomReq = 0
dexterityReq = 0
constitutionReq = 0

strength = [random.randint(3,18), 0, 0, "strength"]
intelligence = [random.randint(3,18), 0, 0, "intelligence"]
wisdom = [random.randint(3,18), 0, 0, "wisdom"]
dexterity = [random.randint(3,18), 0, 0, "dexterity"]
constitution = [random.randint(3,18), 0, 0, "constitution"]
attributeArray = [strength, intelligence, wisdom, dexterity, constitution]

classes = ["Warrior", "Wizard", "Thief", "Necromancer"]
i = 1
characterSelected = ""
space = "                                                                                                               "
for char in classes:
    print("{}) {}".format(i, char))
    i += 1

character = input("\nSelect character: ")

characterSelected = classes[character-1]
print("You have selected {}\n".format(characterSelected))

requiredPoints = 0
surplusPoints = 0


def anotherFix(fixAttr, attrName, attrReq):
    i = 0
    print("\n{} is at {} and needs to be {}".format(attrName, fixAttr, attrReq)) 
    for attr in attributeArray:
        if attr[1] == 0 and attr[0] > 4:
            i += 1
            print("{}) {} - {}".format(i, attr[3], attr[0]))
    select = input("\nPlease select an attribute to take from: ")
    i = 0
    for attr in attributeArray:
        if attr[1] == 0 and attr[0] > 4:
            i += 1
            if i == select:
                attr[0] -= 2
                return fixAttr + 1

    return fixAttr


def printTable():
    for attr in attributeArray:
        st = attr[3] + space
        st = st[:20]
        print(st +  str(attr[0]))
    

def fix():
    surplus = 0
    required = 0
    surplusFixed = 0
    for attr in attributeArray:
        attr[2] = attr[1] - attr[0]
        if attr[1] > 0:
            print("{} requires {} and has {}, the difference is {}".format(attr[3], attr[1], attr[0], attr[2]))
            if attr[2] > 0:
                required += attr[2]
        if attr[1] == 0:
            print("{} has {}, and is a surplus attribute".format(attr[3], attr[0]))
            surplus += attr[0] - 3

    surplusFixed = surplus / 2
    print("\nyou require {} points and you have {} surplus points, this means you can fix {} points".format(required, surplus, surplusFixed))
    
    if surplusFixed < required:
        print("\nYou do not have enough surplus points to create this character, please try again")
        quit()

    if surplusFixed > required:
        print("\nCongratulations! You are able to create this character")

    if required > 0:
        for attr in attributeArray:
            if attr[1] > 0:
                while attr[0] < attr[1]:
                    attr[0] = anotherFix(attr[0], attr[3], attr[1])

    print("You have created your {}! Their attributes are:\n".format(characterSelected)) 
    printTable()
        
        

    


if character == 1:
    strength[1] = 15
    dexterity[1] = 12
    constitution[1] = 10
    
if character == 2:
    intelligence[1] = 15
    wisdom[1] = 10
    dexterity[1] = 10

if character == 3:
    strength[1] = 10
    intelligence[1] = 9
    dexterity[1] = 15

if character == 4:
    strength[1] = 10
    intelligence[1] = 10
    wisdom[1] = 15

fix()






