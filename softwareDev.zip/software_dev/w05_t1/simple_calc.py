first = float(input("First number: "))
second = float(input("Second number: "))
operator = raw_input("Operator: ")
answer = 0.0

if "*" is operator:
    answer = first*second
elif "/" is operator:
    answer = first/second
elif "+" is operator:
    answer = first+second
elif "-" is operator:
    answer = first-second
else:
    print("You have not entered a valid operator")
    quit()

if answer%1 > 0:
    print("Your calculation is {:.0f} {} {:.0f} and the answer is {:.2f}".format(first, operator, second, answer))
else:
    print("Your calculation is {:.0f} {} {:.0f} and the answer is {:.0f}".format(first, operator, second, answer))
