userInput = input("Enter thunderbird number: ")
acceptable = [1,2,3,4]

if userInput not in acceptable:
	print("Have you never watched Thunderbirds!")
	quit()

if userInput == 1:
	print("Thunderbird 1 pilot is Scott Tracy")

if userInput == 2:
	print("Thunderbird 2 pilot is Virgil Tracy")

if userInput == 3:
	print("Thunderbird 3 pilot is Alan Tracy")

if userInput == 4:
	print("Thunderbird 4 pilot is Gordon Tracy")


