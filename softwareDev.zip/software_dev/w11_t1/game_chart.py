"""
For each game the data required is Game Title, Publisher and Number of Sales
	Your program should display a menu consisting of 4 options and Quit.
	1. Enter new game details
	2. Update game sales figures
	3. Remove game
	4. Print chart
	5. Quit
"""

games = []

class Game():
    def __init__(self):
        global games
        self._game_title = str()
        self._publisher = str()
        self._number_of_sales = int()
        self._order = int()
        games.append(self)

    def new_game(self):
        self.set_title(raw_input("Enter Game Title: "))
        self.set_publisher(raw_input("Enter Publisher: "))
        self.set_number_of_sales(raw_input("Enter number of sales: "))
        self.order()

    def order(self):
        tmp = 1
        for game in games:
            if game.get_number_of_sales() > self.get_number_of_sales():
                tmp += 1
        self.set_order(tmp)

    def set_order(self, order):
        self._order = order

    def get_order(self):
        return self._order

    def set_title(self, game_title):
        self._game_title = game_title

    def get_title(self):
        return self._game_title

    def set_publisher(self, publisher):
        self._publisher = publisher

    def get_publisher(self):
        return self._publisher

    def set_number_of_sales(self, number_of_sales):
        self._number_of_sales = int(number_of_sales)

    def get_number_of_sales(self):
        return int(self._number_of_sales)

    def remove_game(self):
        games.remove(self)

loopMsg = """\n\n1. Enter new game details
2. Update game sales figures
3. Remove game
4. Print chart
5. Quit"""
blank = "                                                                                          "

def printTable():
    global games

    for game in games:
        game.order()
    
    tmp = "\n"
    tmp += "Position" + blank
    tmp = tmp[:15]
    tmp += "Title" + blank
    tmp = tmp[:40]
    tmp += "Publisher" + blank
    tmp = tmp[:60]
    tmp += "Sales"
    print(tmp)
    for i in range(1, 6):
        for game in games:
            if game.get_order() == i:
                tmp = ""
                tmp += str(game.get_order()) + blank
                tmp = tmp[:15]
                tmp += game.get_title() + blank
                tmp = tmp[:40]
                tmp += game.get_publisher() + blank
                tmp = tmp[:60]
                tmp += str(game.get_number_of_sales())
                print(tmp)
    
a = Game()
a.set_title("iGoober")
a.set_publisher("Orange")
a.set_number_of_sales(10)
a = None

a = Game()
a.set_title("Call of Deputy")
a.set_publisher("Disney")
a.set_number_of_sales(5000)
a = None

a = Game()
a.set_title("flirtnite")
a.set_publisher("Adult Gaming")
a.set_number_of_sales(100)
a = None

a = Game()
a.set_title("building simulator")
a.set_publisher("Addict Gaming")
a.set_number_of_sales(7100)
a = None

a = Game()
a.set_title("spreadsheet manager")
a.set_publisher("EA Office")
a.set_number_of_sales(1100)
a = None

a = Game()
a.set_title("Slow and laborious")
a.set_publisher("Driving Instructor")
a.set_number_of_sales(1)
a = None


while True:
    print(loopMsg)
    user = input("\nEnter your selection: ")

    if user == 1:
        newGame = Game()
        newGame.new_game()

    if len(games) > 0:

        if user == 2:
            i = 0
            for game in games:
                i += 1
                print("{}) {}".format(i, game.get_title()))
            select = input("Enter your selection: ") - 1
            games[select].set_number_of_sales(input("Enter updated sales figures: "))

        if user == 3:
            i = 0
            for game in games:
                i += 1
                print("{}) {}".format(i, game.get_title()))
            select = input("Enter your selection: ") - 1
            games[select].remove_game()

        if user == 4:
            printTable()

    if user == 5:
        quit()





    
