userInput = input("Enter an odd or even number: ")

if(userInput%2 < 1):
    print(str(userInput) + " is an EVEN number")
else:
    print(str(userInput) + " is an ODD number")
