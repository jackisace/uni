userInput = []

for i in range(0,5):
    userInput.append(input("Enter an integer: "))

pos = 0
neg = 0

for i in userInput:
    if i > 0:
        pos += i
    if i < 0:
        neg += i

print("Sum of positive integers: " + str(pos))
print("Sum of negative integers: " + str(neg))
