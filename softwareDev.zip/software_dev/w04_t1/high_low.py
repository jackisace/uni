import random

print("\nYour first card:")
card = random.randint(1,13)
print("Random card number: " + str(card))
if(card == 1):
    print("Ace")
if(card == 11):
    print("Jack")
if(card == 12):
    print("Queen")
if(card == 13):
    print("King")
if(card > 1 and card < 11):
    print(card)

userInput = raw_input("\nHigher, or lower?: ")

print("\nYour second card:")
newCard = random.randint(1,13)
if(newCard == 1):
    print("Ace")
if(newCard == 11):
    print("Jack")
if(newCard == 12):
    print("Queen")
if(newCard == 13):
    print("King")
if(newCard > 1 and newCard < 11):
    print(newCard)

print("")

if("l" in userInput):
    if(newCard < card):
        print("Winner")
    else:
        print("Loser")

if("h" in userInput):
    if(newCard > card):
        print("Winner")
    else:
        print("Loser")
    
    


