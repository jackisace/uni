passwords = []

while True:
    print("\n\n1. New User")
    print("2. Existing User\n")
    try:
        selection = input("Enter your selection: ")
    except NameError:
        print("NameError exception:\nPlease a valid option next time :)")
    if selection is 1:
        print("\nPlease enter a password with the following rules:")
        print("Longer than 8 characters")
        print("Cannot contain a space")
        print("Cannot begin with a number\n")
        confirmPass = ""

        newPass = raw_input("New password: ")
        valid = True
        if len(newPass) < 8:
            print("Password is shorter than the required length")
            valid = False
        if " " in newPass:
            print("Password contains a space")
            valid = False
        if newPass[0].isdigit():
            print("First character is a number")
            valid = False

        if valid:
            confirmPass = raw_input("Please confirm this password: ")
        else:
            print("\nThis password is invalid")
            continue
        if confirmPass == newPass:
            passwords.append(newPass)
            print("\nYour password has been added to the system")
        else:
            print("\nThese passwords are not the same")

    elif selection is 2:
        user = raw_input("\nEnter password: ")
        valid = False
        for password in passwords:
            if password == user:
                valid = True
                break
        if valid:
            print("\nCongratulations, you have entered the system")
            raw_input("Press enter to continue: ")
        else:
            print("\nThat password was invalid")
    else:
        print("\nPlease enter a valid option next time :)")



