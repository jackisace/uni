votes = [0,0,0,0,0]

voting = True
while voting:
    try:
        vote = input("Enter your rating from 1 to 5: ")
    except NameError:
        print("NameError exception:\nPlease enter a number next time\n")
        continue
    if vote is -1:
        voting = False
        continue
    if vote < 1 or vote > 5:
        print("Please enter a vote between 1-5\n")
    else:
        print("Thank you for your vote\n")
        votes[vote-1] += 1

average = 0.00
multiplier = 1
numVotes = 0

for vote in votes:
    numVotes += vote
    average += vote * multiplier
    multiplier += 1

try:
    average /= numVotes
except ZeroDivisionError:
    print("ZeroDivisionError exception:\nThere are not enough votes to process the table")
    quit()

print("\n\nVery good:      {}".format(votes[4]))
print("Good:           {}".format(votes[3]))
print("Average:        {}".format(votes[2]))
print("Bad:            {}".format(votes[1]))
print("Very bad:       {}".format(votes[0]))
print("\nAverage Rating: {}".format(average))



