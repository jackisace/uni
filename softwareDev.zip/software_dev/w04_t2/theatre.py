# -*- coding: utf-8 -*-

adultPrice = 10.5
childPrice = 7.3
concessionsPrice = 8.4

adults = input("Number of adults in party: ")
children = input("Number of children in party: ")
concessions = input("Number of over concessions in party: ")
collection = raw_input("Tickets to be posted? (y/n): ")
print("\n\n")

if children > 0 and adults < 1:
    print("Not enough adults in party with children")
    quit()

if "y" in collection.lower():
    collection = True
else:
    collection = False

freeAdults = int(children / 10)

if freeAdults > adults:
    print(str(adults) + " free adult tickets applied")
else:
    if freeAdults > 0:
        print(str(freeAdults) + " free adult tickets applied")

adults -= freeAdults
if adults < 0:
    adults = 0

totalBill = (adults*adultPrice) + (children*childPrice) + (concessions*concessionsPrice)

if totalBill > 100:
    print("10% discount applied")
    totalBill *= 0.9

print("Adult tickets price: 				£{:.2f}".format(adults*adultPrice))
print("Children tickets price: 			£{:.2f}".format(children*childPrice))
print("Concession tickets price: 			£{:.2f}".format(concessions*concessionsPrice))

if collection:
    totalBill += 2.34
    print("Tickets postage&packaging price: 		£2.34")
print("Total bill is:					£{:.2f}".format(totalBill))

