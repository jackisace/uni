userInput = input("Enter a number: ")
permittedNumbers = [1,2,3,4,5,6,7]

if userInput == 1:
    print("One for sorrow")
if userInput == 2:
    print("Two for joy")
if userInput == 3:
    print("Three for a girl")
if userInput == 4:
    print("Four for a boy")
if userInput == 5:
    print("Five for gold")
if userInput == 6:
    print("Six for gold")
if userInput == 7:
    print("Seven for a secret never to be told")
if userInput not in permittedNumbers:
    print("Not a permitted number")

