password = "H4rdC0ded"

userInput = raw_input("Enter the password: ")

if(password.lower() == userInput.lower()):
    print("Welcome to the program")
else:
    print("Password invalid")
