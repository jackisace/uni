num1 = float(input("Enter first integer: "))
num2 = float(input("Enter second integer: "))
num3 = float(input("Enter third integer: "))
num4 = float(input("Enter fourth integer: "))

avg = (num1 + num2 + num3 + num4) / 4
print("Average is: " + str(avg))
