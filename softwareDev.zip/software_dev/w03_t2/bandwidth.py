mega = 1000000
maximumNetworkBandwidth = 1000 * mega
numberofUsers = 200
applicationA = 200000
applicationB = 100000
applicationC = 350000

currentUsage = (applicationA+applicationB) * numberofUsers
currentAvailability = maximumNetworkBandwidth - currentUsage
postUsage = (applicationA+applicationB+applicationC) * numberofUsers
postAvailability = maximumNetworkBandwidth - postUsage


print("Network capacity: " + str(maximumNetworkBandwidth)) + " bps"
print("Current usage: " + str(currentUsage) + " bps")
print("Current availability: " + str(currentAvailability) + " bps")
print("New applications requirements: " + str(applicationC) + " bps")
print("Bandwidth available post installaton: " + str(postAvailability / mega) + " Mbps")
