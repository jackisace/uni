# -*- coding: utf-8 -*-

minutes = input("Enter number of minutes: ")

callRate = 0.15
vatRate = 20
callCharge = minutes * callRate
vatDue = callCharge * vatRate / 100 
totalBill = callCharge + vatDue

print("Number of minutes used: {}".format(minutes))
print("Basic call charge: £{:.2f}".format(callCharge))
print("VAT due: £{:.2f}".format(vatDue))
print("Total bill: £{:.2f}".format(totalBill))
