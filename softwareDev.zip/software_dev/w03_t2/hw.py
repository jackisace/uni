for i in range(0, 25):
    print("hw")
