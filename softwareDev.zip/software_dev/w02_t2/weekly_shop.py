print("Peaches")
peachNum = int(input("-how many? "))
peachPrice = float(input("-price? "))
peachTotal = peachNum*peachPrice
print("Beans")
beansNum = int(input("-how many? "))
beansPrice = float(input("-price? "))
beansTotal = beansNum*beansPrice
print("Chicken pieces")
chickenNum = int(input("-how many? "))
chickenPrice = float(input("-price? "))
chickenTotal = chickenNum*chickenPrice
print("Socks")
socksNum = int(input("-how many? "))
socksPrice = float(input("-price? "))
socksTotal = socksNum*socksPrice
print("Bottle of water")
waterNum = int(input("-how many? "))
waterPrice = float(input("-price? "))
waterTotal = waterNum*waterPrice

print("Total number of items purchased: " + str(peachNum+beansNum+chickenNum+socksNum+waterNum))
print("Your weekly shop cost: " + str(float(peachTotal+beansTotal+chickenTotal+socksTotal+waterTotal)))
