width = int(input("Enter the width: "))
height = int(input("Enter the height: "))
length = int(input("Enter the length: "))

#SA=2lw+2lh+2hw
surfaceArea = (2*length*width) + (2*length*height) + (2*height*width)
volume = width*height*length

print("Surface area is: " + str(surfaceArea))
print("Volume is: " + str(volume))
