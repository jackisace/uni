age = int(input("Please enter your age: "))
print("Current age is: " + str(age))
print("Age before last birthday was: " + str(age - 1))

