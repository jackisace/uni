
def printBoard():
    print("  1\t 2\t 3\t 4\t 5")
    i = 0
    for row in grid:
        i += 1
        tmp = str(i)
        for cell in row:
            tmp += cell + "\t"
        print(tmp)

def detectHit(row, column):
    for i in ship:
        if i[0] == row and i[1] == column:
            return True
    return False

grid = []

for i in range(0, 5):
    tmp = []
    tmp.append("[ ]")
    tmp.append("[ ]")
    tmp.append("[ ]")
    tmp.append("[ ]")
    tmp.append("[ ]")
    grid.append(tmp)

ship = [[2, 2], [2, 3]]

hits = 0
shots = 0
while True:
    printBoard()
    user = raw_input("Enter a shot (r c): ")
    try:
        row = int(user[0]) - 1
        column = int(user[2]) - 1
    except:
        print("Invalid number, please try again")
        continue
    if column < 1 or column > 5:
        print("Invalid number, please try again")
        continue
    if row < 1 or row > 5:
        print("Invalid number, please try again")
        continue

    shots += 1
    if detectHit(row, column):
        print("\nNice shot, you hit!")
        grid[row][column] = "[H]"
        hits += 1
        if hits == 2:
            printBoard()
            print("\nCongratulations! You have won the game!")
            print("It took you {} shots\n".format(shots))
            quit()
    else:
        print("\nUnlucky, you missed!\n")
        grid[row][column] = "[M]"



