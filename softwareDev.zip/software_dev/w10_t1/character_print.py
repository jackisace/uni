def printChar(strIn):
    character = ""
    number = ""

    for i in strIn:
        if i.isdigit():
            number += str(i)
        else:
            character += i
    number = int(number)

    for i in range(0, number):
        print(character)
    

user = raw_input("Enter a number and a character: ")

printChar(user)

