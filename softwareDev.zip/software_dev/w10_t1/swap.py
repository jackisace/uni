def swap(strIn):
    temp = strIn.split(" ")
    tmp = []    
    length = len(temp) - 1
    for i in temp:
        tmp.append(temp[length])
        length -= 1
    return tmp

def print_int_list(listIn):
    tmp = ""
    for i in listIn:
        tmp += i + " "
    print("Your numbers swapped are: " + tmp)

user = raw_input("Enter 2 integers: ")
ints = swap(user)
print_int_list(ints)
