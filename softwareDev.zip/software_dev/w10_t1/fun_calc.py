def multiply(a, b):
    print("{} * {} = {}".format(a, b, a*b))
def divide(a, b):
    print("{} / {} = {}".format(a, b, a/b))
def add(a, b):
    print("{} + {} = {}".format(a, b, a+b))
def subtract(a, b):
    print("{} - {} = {}".format(a, b, a-b))
def remainder(a, b):
    print("the remainder of {} / {} = {}".format(a, b, a%b))


numberA = input("Enter first number: ")
numberB = input("Enter second number: ")
options = """
1. Add
2. Subtract
3. Multiply
4. Divide
5. Remainder
"""
print(options)

select = input("Select what function you want to use: ")
if select == 1:
    add(numberA, numberB)
if select == 2:
    subtract(numberA, numberB)
if select == 3:
    multiply(numberA, numberB)
if select == 4:
    divide(numberA, numberB)
if select == 5:
    remainder(numberA, numberB)


