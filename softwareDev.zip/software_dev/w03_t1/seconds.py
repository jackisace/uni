secondsIn = input("Input number of seconds: ")
minutes = secondsIn/60
seconds = secondsIn%60
hours = minutes/60
minutes = minutes%60

secondsIn = str(secondsIn)
hours = str(hours)
minutes = str(minutes)
seconds = str(seconds)

print("Input\tHours\tMinutes\tSeconds")
print(secondsIn + "\t" + hours + "\t" + minutes + "\t" + seconds)

