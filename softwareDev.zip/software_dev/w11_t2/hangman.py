word = raw_input("Enter the word to be guessed: ")

playing = True
guesses = 0
hidden = []
for letter in word:
    hidden.append("-")

while playing:
    display = "Display: "
    hiddenStr = ""
    for letter in hidden:
        hiddenStr += letter
    print(display + hiddenStr)
    if hiddenStr in word:
        print("Congratulations, you have won! The word was {} and it took {} guesses".format(word, guesses))
        playing = False
        continue

    guess = raw_input("Enter letter to guess: ")
    i = 0
    correct = False
    for letter in word:
        if guess in letter:
            hidden[i] = guess
            correct = True
        i += 1
    guesses += 1

    

