user = raw_input("Enter your name: ")
user = user.split(" ")
print("Your initials are: {}{}".format(user[0][0], user[1][0]))
