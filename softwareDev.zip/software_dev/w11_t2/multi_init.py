user = raw_input("Enter your name: ")
user = user.split(" ")
initials = ""

for name in user:
    name = name.upper()
    if len(name) < 1:
        continue
    if "-" in name:
        initials += name[0]
        initials += "-"

        initials += name.split("-")[1][0]
        initials += "."
        continue

    initials += name[0]
    initials += "."

print("Initials are: " + initials)
