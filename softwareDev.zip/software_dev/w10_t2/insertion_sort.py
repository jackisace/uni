

array = []

for i in range(0,5):
    array.append(input("Enter integer: "))

for i in range(0, len(array)):
    value = array[i]
    j = i -1
    while j >= 0 and array[j] > value:
        array[j+1] = array[j]
        j = j -1
    array[j+1] = value

for i in array:
    print(i)




