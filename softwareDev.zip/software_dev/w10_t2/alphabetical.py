"""
list. The program should then sort the input into alphabetical order and then output it.
	Write the code necessary to prompt the user for the required data and output the sorted data.
	Run the program and input appropriate data taking a screen shot of your output. Call your screenshot alphabetical.jpg.

"""


strings = []

for i in range(0,5):
    strings.append(raw_input("Enter your string here: "))


for i in range(0,5):
    print(sorted(strings)[i])
