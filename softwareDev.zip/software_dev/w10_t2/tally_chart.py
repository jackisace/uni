"""
A program is required to register user votes for a talent contest involving 5 candidates. The user will select the candidate they wish to vote for in order to register their vote.
	When all the votes have been cast the program should sort the candidates into order based on the number of votes they have received. The result will then be output to the screen.
	Your program should display the list of candidates and prompt the user to vote for a candidate. The program should continue prompting for a vote until -1 is entered.
	After each vote is cast your program should redisplay the candidate list.
	Write, run and test your program with each candidate receiving at least 1 vote and a clear winner being produced. Take a screen shot of your tested output called tally_chart.jpg.

"""

approved = [1,2,3,4,5]
contestants = [["Iron Man", 0], ["Beyonce",0], ["Sherlock Holmes",0], ["David Attenborough",0], ["Justin Timberlake",0]]

user = 0
while user != -1:
    print("1) Iron Man")
    print("2) Beyonce")
    print("3) Sherlock Holmes")
    print("4) David Attenborough")
    print("5) Justin Timberlake")
    user = input("\nEnter your Selection: ")
    if user in approved:
        contestants[user-1][1] += 1

order = []
for contestant in contestants:
    order.append(contestant[1])
order = sorted(order, reverse = True)

winner = "No one yet"
first = True
print("\n\n\n")
for i in order:
    for contestant in contestants:
        if contestant[1] == i:
            print("{} votes - {}".format(i, contestant[0]))
            if first:
                winner = contestant[0]
                first = False
            contestants.remove(contestant)

print("\n\n" + winner + " is the winner!")
