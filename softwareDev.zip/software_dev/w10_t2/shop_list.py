shop_list = []
for i in range(0, 5):
    shop_list.append(raw_input("Enter your item and price here: "))

prices = []
for line in shop_list:
    num = ""
    isNum = False
    for letter in line:
        if not letter.isalpha():
            isNum = True
        if isNum:
            num += letter
    prices.append(float(num))
prices = sorted(prices, reverse = True)

for price in prices:
    for item in shop_list:
        if str(price) in item:
            print(item)
