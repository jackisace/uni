import time
import random


jacks = 4
queens = 4
kings = 4
aces = 4

deck = []
for i in range(0,4):
    deck.append("j")
    deck.append("q")
    deck.append("k")
    deck.append("a")

shown = []
cards = []
for i in range(0,16):
    r = random.randint(0, len(deck)-1)
    cards.append(deck[r])
    deck.pop(r)

rows = []
for i in range(0,4):
    row = [cards[0], cards[1], cards[2], cards[3]]
    rows.append(row)
    cards.pop(0)
    cards.pop(0)
    cards.pop(0)
    cards.pop(0)
    shown.append(["*", "*", "*", "*"])


def printTable():
    for i in range(0,50):
        pass
        #print("")
    print("\n\t1\t2\t3\t4")
    for i in range(0,4):
        print("{}\t{}\t{}\t{}\t{}".format(i+1, shown[i][0], shown[i][1], shown[i][2], shown[i][3]))

matched = 0
selections = 0

printTable()
while True: 

    rowIn1 = input("Select Row: ") - 1
    columnIn1 = input("Select Column: ") - 1
    if shown[rowIn1][columnIn1] != "*":
        print("You cannot make this selection")
        continue
    shown[rowIn1][columnIn1] = rows[rowIn1][columnIn1]
    cardA = rows[rowIn1][columnIn1]
    printTable()

    rowIn2 = input("Select Row: ") - 1
    columnIn2 = input("Select Column: ") - 1
    if shown[rowIn2][columnIn2] != "*":
        print("You cannot make this selection")
        continue
    shown[rowIn2][columnIn2] = rows[rowIn2][columnIn2]
    cardB = rows[rowIn2][columnIn2]

    printTable()


    if cardA == cardB:
        print("Well done! you matched a pair!")
        shown[rowIn1][columnIn1] = "X"
        shown[rowIn2][columnIn2] = "X"
        matched += 1
        if matched == 8:
            print("\nWell done, you have won! You made {} selections".format(selections))
    else:
        print("Unlucky! Try again!")
        shown[rowIn1][columnIn1] = "*"
        shown[rowIn2][columnIn2] = "*"

    selections += 1






