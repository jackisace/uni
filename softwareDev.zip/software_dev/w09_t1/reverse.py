user = []
for i in range(0,5):
    user.append(input("Input an integer: "))
j = 1
reverse = ""
for i in user:
    reverse += str(user[len(user) - j])
    reverse += " "
    j += 1

print(reverse)
