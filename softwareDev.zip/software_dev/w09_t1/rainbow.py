rainbow = ["Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet"]

while True:
    user = input("Enter an integer from 1-7 or -1 to exit: ")
    if user == -1:
        print("Program end")
        quit()
    if user == 0:
        print("Please select a valid number")
        continue
    if user > 7:
        print("Please select a valid number")
        continue
    print(rainbow[user-1])

