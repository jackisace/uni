# output Hello World

print("Hello World")
print("Welcome to Python")
