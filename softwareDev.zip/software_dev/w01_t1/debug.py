# exercise to debug code

name = "John Smith";  # remove one character
occupation = "Student"  # replace one character
location = "Stoke-on-Trent"  # replace one character
activityLevel = "moderate"  # replace one character (too many spaces)

print("My name is " + name) #add one character
print("I am a student in " + location)  # no errors in this line

age = 21  # remove a character

print("I am " + str(age) + " years of age with a " + activityLevel + " activity level")
# add one character and replace one character

