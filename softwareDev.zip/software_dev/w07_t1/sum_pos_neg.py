pos = 0
nPos = 0
avgPos = 0

neg = 0
nNeg = 0
avgNeg = 0

for i in range(0,10):
    user = input("Please enter a positive or negative integer: ")
    if user > 0:
        pos += user
        nPos += 1
    if user < 0:
        neg += user
        nNeg += 1


if nPos > 0:
    avgPos = pos / nPos
    print("\nThe sum of positive numbers is: " + str(pos))
    print("The average of positive numbers is: " + str(avgPos))
else:
    print("\nThere were no positive numbers used")

if nNeg > 0:
    avgNeg = neg / nNeg
    print("\nThe sum of negative numbers is: " + str(neg))
    print("The average of negative numbers is: " + str(avgNeg))
else:
    print("\nThere were no negative numbers used")
