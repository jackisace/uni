mid = 0

mid = input("Enter the width of the diamond: ")
width = mid * 2

if mid < 2:
    print("Please select a number greater than 2 next time")
    quit()

if mid > 40:
    print("Please select a number less than 40 next time")
    quit()


diamond = []
st = ""
bl = ""

for i in range(0, width):
    st += "*"
    bl += " "

# Top
tmp = bl[:mid] + "*"
diamond.append(tmp)
# Top

# Top -1
l = mid/3*2
r = width-l - l
tmp = bl[:l] + st[:r] + bl[:l] 
diamond.append(tmp)
# Top -1

# Top -2
l = mid/3
r = width-l - l
tmp = bl[:l] + st[:r] + bl[:l] 
diamond.append(tmp)
# Top -2

# Middle
tmp = st
diamond.append(st)
# Middle

# Bottom -2
l = mid/3
r = width-l - l
tmp = bl[:l] + st[:r] + bl[:l] 
diamond.append(tmp)
# Bottom -2

# Bottom -1
l = mid/3*2
r = width-l - l
tmp = bl[:l] + st[:r] + bl[:l] 
diamond.append(tmp)
# Bottom -1

# Bottom
tmp = bl[:mid] + "*"
diamond.append(tmp)
# Bottom

for i in diamond:
    print(i)




