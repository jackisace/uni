rows = input("Enter the number of rows: ")
columns = input("Enter the number of columns: ")
grid = "\n"

for i in range(0, rows):
    for j in range(0, columns):
        grid += "*\t"
    grid += "\n"

print(grid)


