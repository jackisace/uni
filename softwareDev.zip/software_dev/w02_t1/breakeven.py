def calculateBreakEven(itemCost, salePrice, profitPerItem, fixedCosts):
    breakEven = fixedCosts / (salePrice - itemCost)

    print("Cost to produce each item: " + str(itemCost))
    print("Sale price for each item: " + str(salePrice))
    print("Fixed costs: " + str(fixedCosts))
    print("Profit per item: " + str(profitPerItem))
    print("Breakeven: " + str(breakEven))

    return 0


calculateBreakEven(20.0, 40.0, 20.0, 50000.0)
