import math

canCoverage = 5.1
canDiameterCM = 15.0
canHeightCM = 30.0
boxL = 60.0
boxW = 30.0
boxH = 35.0

hallWallCoverage = (40 + 40 + 30 + 30) * 3.4
minimumCans = int(math.ceil(hallWallCoverage / canCoverage))
cansPerBox = int(math.floor((boxL/canDiameterCM))*math.floor((boxW/canDiameterCM))*math.floor((boxH/canHeightCM)))
fullBoxes = int(math.floor(minimumCans/cansPerBox))
looseCans = int(math.floor(minimumCans%cansPerBox)) 

print("The minimum number of cans required: " + str(minimumCans))
print("The number of full boxes given to the customer who buys this quantity of paint: " + str(fullBoxes))
print("The number of cans not packed into boxes: " + str(looseCans))

