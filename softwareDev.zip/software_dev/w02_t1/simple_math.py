age = 2.0
print(age)
age = 21.0
print(age)
age = age + 1.0
print("Age next Birthday: " + str(age))

