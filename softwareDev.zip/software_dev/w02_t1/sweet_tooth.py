sweets = 40
children = 14
perChild = sweets/children
teacher = sweets%children


print("Each child will receive " + str(perChild) + " sweets")
print("The teacher will keep " +str(teacher) + " sweets")
