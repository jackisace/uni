diceA = -1
diceB = 0
import random
throws = 0

while diceA != diceB:
    diceA = random.randint(1,6)
    diceB = random.randint(1,6)
    throws += 1
    print("A: {}\t\tB: {}".format(diceA, diceB))

print("\nIt took {} throws for the dice to match".format(throws))
