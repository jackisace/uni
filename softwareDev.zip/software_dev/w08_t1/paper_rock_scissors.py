import random

you = 0
computer = 0
space = "                                                     "

while True:
    winner = ""

    user = raw_input("Rock, paper or scissors?: ")
    user = user.lower()
    if "rock" in user:
        user = "rock"
    elif "paper" in user:
        user = "paper"
    elif "scissors" in user:
        user = "scissors"
    else:
        print("Unknown input!")
        continue

    rand = random.randint(1,3)
    if rand == 1:
        rand = "rock"
    if rand == 2:
        rand = "paper"
    if rand == 3:
        rand = "scissors"

    

    if "rock" in user and "paper" in rand:
        computer += 1
        winner = "\nthe computer has won this round\n"

    if "rock" in user and "scissors" in rand:
        you += 1
        winner = "\nyou have won this round\n"

    if "paper" in user and "rock" in rand:
        you += 1
        winner = "\nyou have won this round\n"

    if "paper" in user and "scissors" in rand:
        computer += 1
        winner = "\nthe computer has won this round\n"

    if "scissors" in user and "rock" in rand:
        computer += 1
        winner = "\nthe computer has won this round\n"

    if "scissors" in user and "paper" in rand:
        you += 1
        winner = "\nyou have won this round\n"

    if winner is "":
        winner = "\nthis round is a tie\n"

    tmp = "\nYou" + space
    tmp = tmp[:21] + "Computer"
    print(tmp)
    tmp = user + space
    tmp = tmp[:20] + rand
    print(tmp)
    tmp = str(you) + space
    tmp = tmp[:20] + str(computer) + "\n"
    print(tmp)

    print(winner)
    
    if you == 3:
        print("Congratulations! You are the winner!")
        quit()

    if computer == 3:
        print("Unlucky, the computer is the winner..")
        quit()
    


