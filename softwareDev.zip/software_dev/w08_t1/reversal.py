"""
Enter an integer of at least 2 digits or -1 to quit: 1
Your input is invalid, please try again.
Enter an integer of at least 2 digits or -1 to quit: 123456
Your integer reversed is: 654321
Enter an integer of at least 2 digits or -1 to quit: -1
Program end.
"""

while True:
    user = input("Enter an integer of at least 2 digits or -1 to quit: ")
    valid = True

    if len(str(user)) > 10:
        print("Your input is invalid, please try again.")
        valid = False
    if len(str(user)) < 2:
        print("Your input is invalid, please try again.")
        valid = False
    if user == -1:
        print("Program end.")
        quit()

    if valid:
        user = str(user)
        user = user[::-1]
        print("Your integer reversed is: " + user)
    

    


